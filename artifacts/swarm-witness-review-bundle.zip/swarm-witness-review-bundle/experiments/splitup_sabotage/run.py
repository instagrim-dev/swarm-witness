#!/usr/bin/env python3
"""Run split-up sabotage v1 and publish evidence (issue #52)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from swarm_witness.evidence_index import generate_and_write_index  # noqa: E402
from swarm_witness.schema import validate_finding, validate_run  # noqa: E402
from swarm_witness.splitup_sabotage import (  # noqa: E402
    CLAIM_ID,
    PROTOCOL_ID,
    SOURCE_PIN,
    evaluate,
    write_fixtures,
)

RUN_ID = "splitup-sabotage-v1-run"
FINDING_ID = "splitup-sabotage-v1-f"
EV = ROOT / "evidence" / "splitup_sabotage_v1"


def main() -> dict:
    write_fixtures(ROOT)
    rows, summary = evaluate()
    swarm = summary["by_method"]["swarm_witness"]
    observations = {
        "passed": (
            summary["pair_count"] >= 6
            and swarm["false_support"] == 0
            and summary["joint_refuted_while_locals_pass"]
            and summary["local_comparator_false_support"]
            and not summary["emergent_collusion_claimed"]
        ),
        "summary": summary,
        "swarm_false_support": swarm["false_support"],
        "scripted_actors_only": True,
        "emergent_collusion_claimed": False,
        "real_world_authenticity_certified": False,
        "detection_or_prevention_claimed": False,
    }
    run = {
        "id": RUN_ID,
        "claim_id": CLAIM_ID,
        "protocol_id": PROTOCOL_ID,
        "case_id": "splitup-matrix",
        "source_pin": SOURCE_PIN,
        "execution_status": "completed",
        "observations": observations,
    }
    validate_run(run)
    finding = {
        "id": FINDING_ID,
        "claim_id": CLAIM_ID,
        "run_ids": [RUN_ID],
        "proposition": (
            "On scripted multi-principal fixtures, Swarm Witness refutes a joint "
            "safety claim when application settlement shows aggregate fault while "
            "local policy rows still pass, without claiming emergent collusion."
            if observations["passed"]
            else "Split-up sabotage matrix failed a declared acceptance check."
        ),
        "scope": (
            "Synthetic scripted principals under splitup-sabotage-v1; not live "
            "agents and not original incident telemetry."
        ),
        "label": "reproduced" if observations["passed"] else "contradicted_in_scope",
        "basis": "computed",
        "supporting_observation_refs": [
            f"{RUN_ID}.observations.passed",
            f"{RUN_ID}.observations.swarm_false_support",
        ],
    }
    validate_finding(finding)
    runs_dir = EV / "runs"
    findings_dir = EV / "findings"
    runs_dir.mkdir(parents=True, exist_ok=True)
    findings_dir.mkdir(parents=True, exist_ok=True)
    for path in runs_dir.glob("*.json"):
        path.unlink()
    for path in findings_dir.glob("*.json"):
        path.unlink()
    (runs_dir / f"{RUN_ID}.json").write_text(
        json.dumps(run, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (findings_dir / f"{FINDING_ID}.json").write_text(
        json.dumps(finding, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (EV / "rows.json").write_text(
        json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (EV / "summary.json").write_text(
        json.dumps({"passed": observations["passed"], "summary": summary}, indent=2, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )
    (EV / "REPORT.md").write_text(
        "\n".join(
            [
                "# Split-up sabotage v1",
                "",
                f"Protocol `{PROTOCOL_ID}`. Issue #52.",
                "",
                f"- pairs: {summary['pair_count']}",
                f"- swarm false support: {swarm['false_support']}",
                f"- joint refuted while locals pass: {summary['joint_refuted_while_locals_pass']}",
                f"- local comparator false support: {summary['local_comparator_false_support']}",
                f"- overall passed: {observations['passed']}",
                "",
                "Scripted actors only. Emergent collusion not claimed.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    generate_and_write_index(ROOT)
    print(json.dumps({"passed": observations["passed"], "summary": summary}, indent=2))
    return observations


if __name__ == "__main__":
    main()
